(function( $ ) {
    'use strict';

     $(function() {
        $(".inline-footnote").click(function(evt) {
            $(this).children('.footnoteContent').toggle(100);
            evt.stopPropagation();
        });
        $('html').on('click', function() {
            $(".inline-footnote .footnoteContent").hide(100);
        });
     });

})( jQuery );